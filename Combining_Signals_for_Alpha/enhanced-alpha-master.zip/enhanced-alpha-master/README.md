# Combining Signals for Enhanced Alpha Project
*Udacity - AI for Trading Nanodegree Program*

## Project Overview
* Combine signals on a random forest for enhanced alpha. 
* Solve the problem of overlapping samples. 

*For the dataset, the end of day from Quotemedia and sector data from Sharadar are used.*
